import 'package:flutter/material.dart';
import 'package:reseller/pages/awal.dart';
import 'package:reseller/pages/home_screen.dart';
import 'package:reseller/main.dart';
class home extends StatefulWidget {
  @override
  _homeState createState() => _homeState();
}
class _homeState extends State<home> {
  @override
  Widget build(BuildContext context) {
    return
        Scaffold(
            //backgroundColor: Colors.blue[100],
            appBar: AppBar(
              //backgroundColor: Colors.blue[100],
              centerTitle: true,
              leading: Icon(
                Icons.mobile_screen_share,
                color: Colors.red,
              ),
              title: Text('Toko TV Dedek Andila',style: TextStyle(color: Colors.red, fontSize: 15),),
              backgroundColor: Colors.black,
            ),
            body: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Container(
                        height: 10,
                        decoration: BoxDecoration(
                          color: Colors.blueGrey,
                        ),
                      ),
                      Image.network(
                          "https://ds393qgzrxwzn.cloudfront.net/resize/m500x500/cat1/img/images/0/iiZmmwbqIS.jpg"),
                      SizedBox(
                        height: 20.0,
                      ),
                  Container(
                   //height: double.infinity,
                     margin: EdgeInsets.only(left: 10,right: 10),
                     child: RaisedButton(
                       onPressed: () {
                         Navigator.of(context).push(   
                           MaterialPageRoute(builder: (context) => Employee()),
                         );
                       },
                       color: Colors.black,
                        textColor: Colors.red,
                       child: Text(
                         'Data Pemesanan',
                         style:
                         TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
                       ),
                     ),
                   ),
                   Container(
                   //height: double.infinity,
                     margin: EdgeInsets.only(left: 10,right: 10),
                     child: RaisedButton(
                       onPressed: () {
                         Navigator.of(context).push(      
                           MaterialPageRoute(builder: (context) => HomeScreen()),
                         );
                       },
                       color: Colors.black,
                        textColor: Colors.red,
                       child: Text(
                         'Halaman Website',
                         style:
                         TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
                       ),
                     ),
                   ),
                ],
              ),
            ),
          bottomNavigationBar: BottomAppBar(
            //color: Colors.transparen,
            child: Container(
              height: 30,
              color: Colors.black,
              alignment: Alignment.center,
              child: Text(
                'Developed by Kadek Andila Kertha Subagia',
                style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                    color: Colors.red),
              ),
            ),
            //elevation: 0,
          ),
        );
  }
}