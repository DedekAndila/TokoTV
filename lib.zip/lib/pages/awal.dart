import 'package:flutter/material.dart';
import 'package:reseller/providers/employee_provider.dart';
import 'package:provider/provider.dart';
import '../models/employee_model.dart';
import 'add.dart';
import 'edit.dart';
import 'home_screen.dart';
class Employee extends StatelessWidget {
  //DUMMY DATA YANG AKAN DITAMPILKAN SEBELUM MELAKUKAN HIT KE API
  //ADAPUN FORMAT DATANYA MENGIKUTI STRUKTU YANG SUDAH DITETAPKAN PADA EMPLOYEEMODEL
  final data = [
    EmployeeModel(
      id: "1",
      employeeName: "Tiger",
      employeeSalary: "320800",
      employeeAge: "61",
      profileImage: "",
    ),
    EmployeeModel(
      id: "2",
      employeeName: "Anugrah Sandi",
      employeeSalary: "40000",
      employeeAge: "25",
      profileImage: "",
    ),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text('Data Pemesan TV',style: TextStyle(color: Colors.red, fontSize: 15),),
      ),
      body: RefreshIndicator(
        onRefresh: () =>
            Provider.of<EmployeeProvider>(context, listen: false).getEmployee(),
        color: Colors.red,
        child: Container(
          margin: EdgeInsets.all(10),
          child: FutureBuilder(
            future: Provider.of<EmployeeProvider>(context, listen: false)
                .getEmployee(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              }
              return Consumer<EmployeeProvider>(
                builder: (context, data, _) {
                  return ListView.builder(
                    itemCount: data.dataEmployee.length,
                    itemBuilder: (context, i) {
                      return InkWell(
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => EmployeeEdit(id: data.dataEmployee[i].id,),
                            ),
                          );
                        },
child: Dismissible(
  key: UniqueKey(), 
  direction: DismissDirection.endToStart,
  confirmDismiss: (DismissDirection direction) async {
    final bool res = await showDialog(context: context, builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Konfirmasi'),
        content: Text('Anda Yakin?'),
        actions: <Widget>[
          FlatButton(onPressed: () => Navigator.of(context).pop(true), child: Text('HAPUS'),),
          FlatButton(onPressed: () => Navigator.of(context).pop(false), child: Text('BATALKAN'),)
        ],
      );
    });
    return res;
  },
  onDismissed: (value) {
    Provider.of<EmployeeProvider>(context, listen: false).deleteEmployee(data.dataEmployee[i].id);
  },
  child: Card(
    elevation: 8,
    child: ListTile(
      title: Text(
        data.dataEmployee[i].employeeName,
        style: TextStyle(
            fontSize: 18, fontWeight: FontWeight.bold),
      ),
      subtitle: Text(
        "Harga: Rp ${data.dataEmployee[i].employeeSalary}"),
         
      trailing: Text(
           'Jumlah: ${data.dataEmployee[i].employeeAge}'),
    ),
  ),
),
                      );
                    },
                  );
                },
              );
            },
          ),
        ),
      ),
          floatingActionButton: FloatingActionButton(
      backgroundColor: Colors.black,
      child: Text('+'),
      onPressed: () {
        //BUAT NAVIGASI UNTUK BERPINDAH KE HALAMAN EMPLOYEEADD
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) => EmployeeAdd()));
      },
    ),
    
    );
     
  }
}